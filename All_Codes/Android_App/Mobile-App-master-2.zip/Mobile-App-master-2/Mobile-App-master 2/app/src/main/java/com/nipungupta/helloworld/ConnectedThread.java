package com.nipungupta.helloworld;

import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Created by Nipun Gupta on 4/20/2016.
 */
public class ConnectedThread extends Thread {
    private final BluetoothSocket mmSocket;
    private final InputStream mmInStream;
    private final OutputStream mmOutStream;
    private Handler mHandler;
    private Context c;

    public ConnectedThread(BluetoothSocket socket, Handler handler, Context receive) {
        mmSocket = socket;
        InputStream tempIn = null;
        OutputStream tempOut = null;
        mHandler = handler;

        try {
            tempIn = socket.getInputStream();
            tempOut = socket.getOutputStream();
        } catch (IOException e) {

        }

        mmInStream = tempIn;
        mmOutStream = tempOut;
        c = receive;
    }

    public void run() {
        byte[] buffer = new byte[1024];
        int bytes;
        Boolean flag = false;

        while(true) {
            GlobalClass check = (GlobalClass) c.getApplicationContext();
            String powerString = check.getPowerVariable();
            String recognitionString = check.getRecognitionVariable();
            String piString = check.getPiVariable();
            //android.util.Log.d("ConnectedThread", powerString);
            if (powerString == "n") {
                if (flag) {
                    try {
                        String writeString = "n" + recognitionString + piString;
                        byte[] buf = writeString.getBytes();

                        mmOutStream.write(buf, 0, buf.length);

                    } catch (IOException e) {
                        break;
                    }
                    flag = false;
                }
                try {
                    android.util.Log.d("ConnectedThread", "Waiting to receive");
                    bytes = mmInStream.read(buffer);
                    android.util.Log.d("ConnectedThread", "Received");
                    String jsonString = new String(buffer, 0, bytes);
                    android.util.Log.d("ConnectedThread", "JsonString: " + jsonString.toString());
                    if (!jsonString.equals(null) && !jsonString.equals("")) {
                        Message msgObj = mHandler.obtainMessage();
                        Bundle b = new Bundle();
                        b.putString("message", jsonString);
                        msgObj.setData(b);
                        mHandler.sendMessage(msgObj);


                    } else {
                        android.util.Log.d("ConnectedThread", "Received null");
                    }

                    //Writing "off" after receiving stuff
                    try {
                        String writeString = "n" + recognitionString + piString;
                        byte[] buf = writeString.getBytes();

                        mmOutStream.write(buf, 0, buf.length);

                    } catch (IOException e) {
                        break;
                    }
                } catch (IOException e) {
                    break;
                }
            } else {
                if (flag == false) {
                    try {
                        String writeString = "f" + recognitionString + piString;
                        byte[] buf = writeString.getBytes();

                        mmOutStream.write(buf, 0, buf.length);

                    } catch (IOException e) {
                        break;
                    }
                    flag = true;
                }
            }

        }
        android.util.Log.d("ConnectedThread", "Exit reading buffer");
    }

    public void cancel() {
        try {
            mmSocket.close();
        } catch (IOException e) {

        }
    }
}
