package com.nipungupta.helloworld;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import net.minidev.json.JSONArray;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Locale;

public class MainActivity extends Activity {

    private Button onBtn;
    private Button offBtn;
    private Button conBtn;
    private Button r1c1Btn;
    private Button r1c2Btn;
    private Button r1c3Btn;
    private Button r2c1Btn;
    private Button r2c2Btn;
    private Button r2c3Btn;
    private Button overallOnBtn;
    private Button overallOffBtn;
    private Button animalDetectOnBtn;
    private Button animalDetectOffBtn;
    private Button faceDetectOnBtn;
    private Button faceDetectOffBtn;
    private Button faceRecognitionOnBtn;
    private Button faceRecognitionOffBtn;
    private  Button piOnBtn;
    private  Button piOffBtn;


    private static final int REQUEST_ENABLE_BT = 1;
    private static final int REQUEST_ENABLE_DSC = 3;
    private static final SignBoard[] signBoardData = {
            new SignBoard(28.5451600, 77.1906900, "Cycle Stand"),
            new SignBoard(28.5448117, 77.1909533, "Use me"),
            new SignBoard(28.5442717, 77.1912483, "Hospital, Boys Hostel, Student Activity Center, West Campus"),
            new SignBoard(28.5440533, 77.1915483, "Canteen, Staff Canteen, Maintenance Unit"),
            new SignBoard(28.5440633, 77.1920300, "IDD Center, Central Workshop"),
            new SignBoard(28.5441883, 77.1920233, "Mathematics Department, Library, Dogra Hall"),
            new SignBoard(28.5443467, 77.1922350, "Canara Bank, I.I.T. Delhi"),
            new SignBoard(28.5445833, 77.1928700, "Please do not walk on grass"),
            new SignBoard(28.5443617, 77.1928617, "Administrative Block, Employees Union"),
            new SignBoard(28.54430012, 77.1932017, "Director's Office, Seminar Hall, Security Control Room, Textile Department, SBI, IDDC, Workshop"),
            new SignBoard(28.5444933, 77.1934367, "Academic Block, Administrative Block, Seminar Hall, Exhibition Hall")
    };

    private String message;
    private Boolean animalDetectVariable = true;
    private Boolean faceDetectVariable = true;
    private boolean currPothole = false;
    private boolean currSignboard = false;
    private boolean faceRecogniseVariable = true;
    private int currFaces = 0;
    private int currAnimals = 0;

    private TextView tv;
    private TextView textView;
    private Handler mHandler;

    private BluetoothAdapter mAdapter;
    private TextToSpeech tts;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final GlobalClass mApp = ((GlobalClass)getApplicationContext());
        tv = (TextView) findViewById(R.id.text);
        textView = (TextView) findViewById(R.id.textCtr);
        mAdapter = BluetoothAdapter.getDefaultAdapter();
        if(mAdapter==null) {
            onBtn.setEnabled(false);
            offBtn.setEnabled(false);
            conBtn.setEnabled(false);
            tv.setText("Status: not supported");
            Toast.makeText(getApplicationContext(),"Your device does not support Bluetooth",Toast.LENGTH_LONG).show();
        } else {
            onBtn = (Button) findViewById(R.id.turnOn);
            onBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    on(v);
                }
            });

            offBtn = (Button) findViewById(R.id.turnOff);
            offBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    off(v);
                }
            });

            conBtn = (Button) findViewById(R.id.connect);
            conBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    connect(v);
                }
            });

            r1c1Btn = (Button) findViewById(R.id.r1c1);
            r1c1Btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    speakTexture(v);
                }
            });

            r1c2Btn = (Button) findViewById(R.id.r1c2);
            r1c2Btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    speakTexture(v);
                }
            });

            r1c3Btn = (Button) findViewById(R.id.r1c3);
            r1c3Btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    speakTexture(v);
                }
            });

            r2c1Btn = (Button) findViewById(R.id.r2c1);
            r2c1Btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    speakTexture(v);
                }
            });

            r2c2Btn = (Button) findViewById(R.id.r2c2);
            r2c2Btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    speakTexture(v);
                }
            });

            r2c3Btn = (Button) findViewById(R.id.r2c3);
            r2c3Btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    speakTexture(v);
                }
            });

            overallOnBtn = (Button) findViewById(R.id.overallOn);
            overallOnBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mApp.setPowerVariable("n");
                }
            });

            overallOffBtn = (Button) findViewById(R.id.overallOff);
            overallOffBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mApp.setPowerVariable("f");
                }
            });

            faceRecognitionOnBtn = (Button) findViewById(R.id.recognitionOn);
            faceRecognitionOnBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mApp.setRecognitionVariable("n");
                    faceRecogniseVariable = true;
                }
            });

            faceRecognitionOffBtn = (Button) findViewById(R.id.recognitionOff);
            faceRecognitionOffBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mApp.setRecognitionVariable("f");
                    faceRecogniseVariable = false;
                }
            });

            piOnBtn = (Button) findViewById(R.id.piOn);
            piOnBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mApp.setPiVariable("r");
                }
            });

            piOffBtn = (Button) findViewById(R.id.piOff);
            piOffBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mApp.setPiVariable("f");
                }
            });

            animalDetectOnBtn = (Button) findViewById(R.id.animalDetectOn);
            animalDetectOnBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    animalDetectVariable = true;
                }
            });

            animalDetectOffBtn = (Button) findViewById(R.id.animalDetectOff);
            animalDetectOffBtn.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                   animalDetectVariable = false;
                }
            });

            faceDetectOnBtn = (Button) findViewById(R.id.faceDetectOn);
            faceDetectOnBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    faceDetectVariable = true;
                }
            });

            faceDetectOffBtn = (Button) findViewById(R.id.faceDetectOff);
            faceDetectOffBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    faceDetectVariable = false;
                }
            });



            mHandler = new Handler(Looper.getMainLooper()) {
                @Override
                public void handleMessage(Message message) {
                    String str = message.getData().getString("message");
                    if(str!=null && !str.equals("")) {

                        handle(str);

                    }
                }
            };

            tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int status) {
                    if(status != TextToSpeech.ERROR) {
                        tts.setLanguage(Locale.UK);
                    }
                }
            });

            //String json = "{\"signBoardString\": {\"isSignBoardDetected\": \"False\"}, \"textureString\": {\"pothole\": \"False\", \"texture\": [[\"1\", \"0\", \"1\"], [\"1\", \"0\", \"1\"]]}, \"positionString\": {\"pos_x\": 1.2314, \"pos_y\": 2.5426, \"pos_z\": 0.1243}, \"faceDetectionString\": {\"noOfFaces\": \"2\", \"nameArray\": [\"Anupam\", \"Anupam\"]}, \"animalDetectionString\": {\"noOfAnimals\": \"2\", \"animalArray\": [\"Cow\", \"Cow\"], \"directionArray\": [\"Left\", \"Left\"] }}";
            //handle(json);
            //double a1 = SignBoard.distanceGPS(28.5451600, 77.1906900, 28.5448117, 77.1909533);
            //double a2 = SignBoard.distanceGPS(28.5448117, 77.1909533, 28.5451600, 77.1906900);
            //displayText(a1+"\n"+a2);
        }
    }

    public void on(View view) {
        if(!mAdapter.isEnabled()) {
            Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(intent, REQUEST_ENABLE_BT);
            Toast.makeText(getApplicationContext(), "Bluetooth turned on", Toast.LENGTH_LONG).show();
        }
        else {
            Toast.makeText(getApplicationContext(), "Bluetooth is already on", Toast.LENGTH_LONG).show();
        }

        Intent discover = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        discover.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 0);
        startActivityForResult(discover, REQUEST_ENABLE_DSC);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode==REQUEST_ENABLE_BT) {
            if(mAdapter.isEnabled()) {
                tv.setText("Status: Enabled");
            } else {
                tv.setText("Status: Disabled");
            }
        }
        else if(requestCode==REQUEST_ENABLE_DSC) {
            if(mAdapter.getScanMode() == BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {
                tv.setText("Status: Enabled and Discoverable");
            } else {
                tv.setText("Status: Enabled but not Discoverable");
            }
        }
    }

    public void off(View view) {
        mAdapter.disable();
        tv.setText("Status: Disconnected");
        Toast.makeText(getApplicationContext(), "Bluetooth turned off", Toast.LENGTH_LONG).show();
    }

    public void connect(View view) {
        AcceptThread accept = new AcceptThread(mAdapter, mHandler, this);
        accept.start();
    }

    public void sendMessage(View view) {
        AcceptThread accept = new AcceptThread(mAdapter, mHandler, this);
        accept.start();
    }

    public void speakTexture(View view) {
        Button button = (Button) view;

        String toSpeak = button.getText().toString();
        if(toSpeak.equals("Not Detected")) {
            toSpeak = "Texture " + toSpeak;
        }

        switch(button.getId()) {
            case R.id.r1c1:
            case R.id.r2c1:
                toSpeak = toSpeak+", on the left";
                break;
            case R.id.r1c2:
            case R.id.r2c2:
                toSpeak = toSpeak+" ahead";
                break;
            case R.id.r1c3:
            case R.id.r2c3:
                toSpeak = toSpeak+" on the right";
                break;
        }

        tts.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null);
    }

    public void handle(String jsonMessage) {
     //   System.out.println(jsonMessage);

        try {
            JSONObject reader = new JSONObject(jsonMessage);

            JsonPath jsonPath = new JsonPath(reader.toString());

            //displayText(reader.toString());
            boolean isPothole = potholeDetect(jsonPath);

            if(!isPothole) {

                boolean isSignDetect = signboardDetect(jsonPath);
                if(!isSignDetect) {
                    boolean isFaceDetect = faceDetect(jsonPath, faceDetectVariable);
                    if(!isFaceDetect) {
                        animalDetect(jsonPath, animalDetectVariable);
                    }
                }
            }

        } catch (JSONException e) {
            Log.e("MYAPP", "unexpected JSON exception", e);
            // Do something to recover ... or kill the app.
        }


    }

    public boolean faceDetect(JsonPath jsonPath, Boolean faceDetectVariable) {
        String temp1 = jsonPath.read("$.faceDetectionString").toString();
        temp1 = temp1.replaceAll("=",":");
        android.util.Log.d("YourTag11", temp1);
        JsonPath fdJson = new JsonPath(temp1);

        int noOfFaces = Integer.parseInt((fdJson.read("$.noOfFaces")).toString());
        if(noOfFaces > 0 && faceDetectVariable) {
            currFaces = noOfFaces;
            message = noOfFaces + " faces detected.\n";
            int noOfRecFaces = ((JSONArray) fdJson.read("$.nameArray")).size();
            if(noOfRecFaces==0) {
                message += "None recognized";
                displayText(message);
            }
            else {
                if(faceRecogniseVariable) {
                    message += "Recognized ";
                    for (int i = 0; i < noOfRecFaces; i++) {
                        message += fdJson.read("$.nameArray[" + i + "]") + ", ";
                        displayText(message);
                    }
                }
                else{
                    displayText(message);
                }
                return true;
            }
        }
        else if(noOfFaces!=currFaces) {
            currFaces = noOfFaces;
        }
        return false;
    }

    public boolean animalDetect(JsonPath jsonPath, Boolean animalDetectVariable) {
        String temp1 = jsonPath.read("$.animalDetectionString").toString();
        temp1 = temp1.replaceAll("=",":");
        android.util.Log.d("YourTag12", temp1);
        JsonPath fdJson = new JsonPath(temp1);

        int noOfAnimals = Integer.parseInt((fdJson.read("$.noOfAnimals")).toString());
        //int noOfAnimals = 1;
        if(noOfAnimals > 0 && animalDetectVariable) {
            currAnimals = noOfAnimals;
            message = noOfAnimals + " animals detected.\n";
            int noOfRecAnimals = ((JSONArray) fdJson.read("$.animalArray")).size();
            if(noOfRecAnimals==0) {
                message += "None recognized";
                displayText(message);
            }
            else {
                //message += "Recognized ";
                for(int i=0; i<noOfRecAnimals; i++) {
                    message += fdJson.read("$.animalArray["+i+"]") + " on ";
                    message += fdJson.read("$.directionArray["+i+"]") + ", ";
                    displayText(message);
                }
                return true;
            }
        }
        else if(noOfAnimals!=currAnimals) {
            currAnimals = noOfAnimals;
        }
        return false;
    }

    public boolean signboardDetect(JsonPath jsonPath) {
        JsonPath sbJson = new JsonPath(jsonPath.read("$.signBoardString").toString().replaceAll("=",":"));
        android.util.Log.d("YourTagInSign", jsonPath.read("$.signBoardString").toString().replaceAll("=",":"));
        boolean isSign = Boolean.parseBoolean((sbJson.read("$.isSignBoardDetected")).toString());
        int sbdcount = Integer.parseInt((sbJson.read("$.sbdCount")).toString());
        //boolean isSign = true;
        if(isSign && !currSignboard) {
            currSignboard = true;
            message = "Sign board detected.";
            JsonPath posJson = new JsonPath( jsonPath.read("$.positionString").toString().replaceAll("=", ":"));
            double latitude = posJson.read("$.pos_x");
            double longitude = posJson.read("$.pos_y");
            int idx = SignBoard.getNextSignBoard(latitude, longitude, signBoardData);
            //message = message + "\n" + signBoardData[idx].getData();
            displayText(message);
            message+= "The board reads ";
            for (int i = 0; i < sbdcount; i++) {
                message += sbJson.read("$.sbdArray[" + i + "]") + ", ";
                displayText(message);
            }

            return true;
        }
        else if(!isSign & currSignboard) {
            currSignboard = false;
            return false;
        }
        return false;
    }

    public boolean potholeDetect(JsonPath jsonPath) {
        android.util.Log.d("YourTag", jsonPath.read("$.textureString").toString().replaceAll("=", ":"));
        //JsonPath jsonPath1 = new JsonPath(jsonPath.read("$.textureString").toString().replaceAll("=", ":"));
        JsonPath tdJson = new JsonPath(jsonPath.read("$.textureString").toString().replaceAll("=", ":"));


        JSONArray textureDesc = tdJson.read("$.texture");
        android.util.Log.d("YourTagInSign", tdJson.read("$.texture").toString().replaceAll("=",":"));
        r1c1Btn.setText(getTextureFromCode( Integer.parseInt(((JSONArray) textureDesc.get(0)).get(0).toString()) ));
        r2c1Btn.setText(getTextureFromCode( Integer.parseInt(((JSONArray) textureDesc.get(0)).get(1).toString()) ));
        r1c2Btn.setText(getTextureFromCode( Integer.parseInt(((JSONArray) textureDesc.get(0)).get(2).toString()) ));
        r1c3Btn.setText(getTextureFromCode( Integer.parseInt(((JSONArray) textureDesc.get(1)).get(0).toString()) ));
        r2c2Btn.setText(getTextureFromCode( Integer.parseInt(((JSONArray) textureDesc.get(1)).get(1).toString()) ));
        r2c3Btn.setText(getTextureFromCode( Integer.parseInt(((JSONArray) textureDesc.get(1)).get(2).toString()) ));

        boolean isPothole = Boolean.parseBoolean((tdJson.read("$.pothole")).toString());
        if(isPothole && !currPothole) {
            currPothole = true;
            message = "Pothole detected. Be careful.";
            displayText(message);
            vibratePhone(500);
            return true;
        }
        else if(!isPothole & currPothole) {
            currPothole = false;
            return false;
        }
        return false;
    }

    public static String getTextureFromCode(int code) {
        if(code==0) {
            return "Other";
        }
        else if(code==1) {
            return "Pavement";
        }
        else if(code==2) {
            return "Road";
        }
        else if(code==3) {
            return "Grass";
        }

        return null;
    }

    protected void displayText(String str) {
        textView.setText(str);
        tts.speak(str, TextToSpeech.QUEUE_FLUSH, null);
    }

    protected void vibratePhone(long timeInMiliSec) {
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        vibrator.vibrate(timeInMiliSec);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
