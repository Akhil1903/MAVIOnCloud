package com.nipungupta.helloworld;

import android.app.Application;

/**
 * Created by SanjeevSanghi on 17/11/16.
 */
public class GlobalClass extends Application {
    private String powerStatus;
    private String recognitionStatus;
    private String piStatus;

    public GlobalClass() {
        powerStatus = "n";
        recognitionStatus = "n";
        piStatus = "n";
    }

    public void setPowerVariable(String someVariable) {
        this.powerStatus = someVariable;
    }

    public String getPowerVariable() {
        return powerStatus;
    }

    public void setRecognitionVariable(String someVariable) { this.recognitionStatus = someVariable; }

    public String getRecognitionVariable() {
        return recognitionStatus;
    }

    public void setPiVariable(String someVariable) {
        this.piStatus = someVariable;
    }

    public String getPiVariable() {
        return piStatus;
    }
}
